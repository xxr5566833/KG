# -*- coding: UTF-8 -*-


class CopyCnnBeamSearch(object):
    def __init__(self):
        pass

    def beam_search(self):
        pass

    def greedy_search(self):
        pass
