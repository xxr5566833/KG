# -*- coding: UTF-8 -*-
import torch
import torch.nn  as nn


class Transformer(nn.Module):
    def __init__(self):
        super().__init__()

    def forward(self):
        torch.max()
        pass


class TransformerEncoder(nn.Module):
    def __init__(self):
        super().__init__()

    def forward(self):

        pass


class TransformerDecoder(nn.Module):
    def __init__(self):
        super().__init__()

    def forward(self):
        pass


class TransformerEncoderLayer(nn.Module):
    def __init__(self):
        super().__init__()

    def forward(self):
        pass


class TransformerDecoderLayer(nn.Module):
    def __init__(self):
        super().__init__()

    def forward(self):
        pass
