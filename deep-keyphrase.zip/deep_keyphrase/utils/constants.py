# -*- coding: UTF-8 -*-
# !! please don't change the value of following variable
PAD_WORD = '<pad>'
UNK_WORD = '<unk>'
BOS_WORD = '<s>'
EOS_WORD = '</s>'
DIGIT_WORD = '<digit>'
SEP_WORD = '<sep>'
